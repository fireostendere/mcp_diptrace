from __future__ import annotations

import difflib
import hashlib
import os
import re
import tempfile
import xml.etree.ElementTree as ET
from copy import deepcopy
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal, Protocol, cast
from xml.parsers import expat

from .errors import DocumentError, EditError

EditOperation = Literal[
    "set_text",
    "set_attribute",
    "remove_attribute",
    "append_xml",
    "replace_xml",
    "delete_element",
]

_FORBIDDEN_XML = re.compile(br"<!\s*(?:DOCTYPE|ENTITY)", re.IGNORECASE)
_FORBIDDEN_XML_TEXT = re.compile(r"<!\s*(?:DOCTYPE|ENTITY)", re.IGNORECASE)
_XML_DECLARATION_ENCODING = re.compile(
    rb"^\s*<\?xml\b[^>]*?\bencoding\s*=\s*([\"'])([^\"']+)\1",
    re.IGNORECASE,
)
_XML_DECLARATION_ENCODING_TEXT = re.compile(
    r"^\s*<\?xml\b[^>]*?\bencoding\s*=\s*([\"'])([^\"']+)\1",
    re.IGNORECASE,
)
_INVALID_XML_10_CHARACTER = re.compile(
    "[\x00-\x08\x0b\x0c\x0e-\x1f\ud800-\udfff\ufffe\uffff]"
)
_ALLOWED_XML_ENCODINGS = frozenset(
    {
        "utf-8",
        "utf-8-sig",
        "utf-16",
        "utf-16-le",
        "utf-16-be",
        "utf-32",
        "utf-32-le",
        "utf-32-be",
        "us-ascii",
        "iso-8859-1",
    }
)
_XML_BOMS: tuple[tuple[bytes, str], ...] = (
    (b"\x00\x00\xfe\xff", "utf-32-be"),
    (b"\xff\xfe\x00\x00", "utf-32-le"),
    (b"\xef\xbb\xbf", "utf-8"),
    (b"\xfe\xff", "utf-16-be"),
    (b"\xff\xfe", "utf-16-le"),
)
_XML_BYTE_SIGNATURES: tuple[tuple[bytes, str], ...] = (
    (b"\x00\x00\x00<", "utf-32-be"),
    (b"<\x00\x00\x00", "utf-32-le"),
    (b"\x00<\x00?", "utf-16-be"),
    (b"<\x00?\x00", "utf-16-le"),
)
ForbiddenXmlContext = Literal["document", "fragment", "pattern_definition"]
_FORBIDDEN_XML_MESSAGES: dict[ForbiddenXmlContext, str] = {
    "document": "DTD and ENTITY declarations are not allowed",
    "fragment": "DTD and ENTITY declarations are not allowed in XML fragments",
    "pattern_definition": "DTD and ENTITY declarations are forbidden in pattern definitions",
}
_XML_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_.:-]*$")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


@dataclass(frozen=True, slots=True)
class _XmlEncoding:
    codec: str
    bom: bytes = b""
    declared_name: str | None = None


def _canonical_encoding_name(value: str) -> str:
    return value.strip().lower().replace("_", "-")


def _declaration_from_prefix(data: bytes, codec: str, bom: bytes) -> str | None:
    body = data[len(bom) :] if bom and data.startswith(bom) else data
    unit_size = 4 if codec.startswith("utf-32") else 2 if codec.startswith("utf-16") else 1
    prefix_size = min(len(body), 4096)
    prefix_size -= prefix_size % unit_size
    try:
        prefix = body[:prefix_size].decode(codec, errors="strict")
    except (LookupError, UnicodeError, ValueError):
        return None
    match = _XML_DECLARATION_ENCODING_TEXT.search(prefix)
    return match.group(2) if match is not None else None


def _declaration_matches_codec(declared: str, codec: str) -> bool:
    normalized = _canonical_encoding_name(declared)
    if normalized == "utf-16":
        return codec in {"utf-16-le", "utf-16-be"}
    if normalized == "utf-32":
        return codec in {"utf-32-le", "utf-32-be"}
    if normalized == "utf-8-sig":
        return codec == "utf-8"
    return normalized == codec


def _expat_encoding_hint(codec: str) -> str | None:
    """Use Expat's generic multibyte names without trusting an XML declaration."""
    if codec.startswith("utf-16"):
        return "utf-16"
    if codec.startswith("utf-32"):
        return "utf-32"
    return None


def _expat_byte_encoding_hint(data: bytes) -> str | None:
    for bom, codec in _XML_BOMS:
        if data.startswith(bom):
            return _expat_encoding_hint(codec)
    for signature, codec in _XML_BYTE_SIGNATURES:
        if data.startswith(signature):
            return _expat_encoding_hint(codec)
    return None


def _detect_xml_encoding(data: bytes) -> _XmlEncoding:
    """Detect the source codec without trusting an arbitrary declaration codec."""

    for bom, codec in _XML_BOMS:
        if not data.startswith(bom):
            continue
        declared = _declaration_from_prefix(data, codec, bom)
        if declared is not None:
            normalized = _canonical_encoding_name(declared)
            if normalized not in _ALLOWED_XML_ENCODINGS:
                raise DocumentError(f"Unsupported XML encoding declaration: {declared!r}")
            if not _declaration_matches_codec(declared, codec):
                raise DocumentError(
                    f"XML declaration encoding {declared!r} conflicts with the byte-order mark"
                )
        return _XmlEncoding(codec=codec, bom=bom, declared_name=declared)

    for signature, codec in _XML_BYTE_SIGNATURES:
        if not data.startswith(signature):
            continue
        declared = _declaration_from_prefix(data, codec, b"")
        if declared is not None:
            normalized = _canonical_encoding_name(declared)
            if normalized not in _ALLOWED_XML_ENCODINGS:
                raise DocumentError(f"Unsupported XML encoding declaration: {declared!r}")
            if not _declaration_matches_codec(declared, codec):
                raise DocumentError(
                    f"XML declaration encoding {declared!r} conflicts with the byte order"
                )
        return _XmlEncoding(codec=codec, declared_name=declared)

    declaration = _XML_DECLARATION_ENCODING.search(data[:4096])
    if declaration is None:
        return _XmlEncoding(codec="utf-8")
    try:
        declared = declaration.group(2).decode("ascii")
    except (LookupError, UnicodeError, ValueError) as exc:
        raise DocumentError("XML encoding declaration must use an ASCII codec name") from exc
    normalized = _canonical_encoding_name(declared)
    if normalized not in _ALLOWED_XML_ENCODINGS:
        raise DocumentError(f"Unsupported XML encoding declaration: {declared!r}")
    if normalized in {"utf-16", "utf-32"}:
        raise DocumentError(
            f"XML encoding {declared!r} requires a BOM or an encoded byte-order signature"
        )
    codec = "utf-8" if normalized == "utf-8-sig" else normalized
    return _XmlEncoding(codec=codec, declared_name=declared)


def _encode_xml_fragment(value: str, codec: str) -> bytes:
    try:
        return value.encode(codec, errors="xmlcharrefreplace")
    except (LookupError, UnicodeError, ValueError) as exc:
        raise EditError(f"Cannot encode XML replacement as {codec}: {exc}") from exc


def _decode_xml_fragment(value: bytes, codec: str) -> str:
    try:
        return value.decode(codec, errors="strict")
    except (LookupError, UnicodeError, ValueError) as exc:
        raise EditError(f"Cannot decode XML source bytes as {codec}: {exc}") from exc


def _encoding_candidates(data: bytes) -> tuple[tuple[str, int], ...]:
    """Return allowlisted decodings that can expose forbidden XML declarations."""
    if data[:4] == b"\x00\x00\xfe\xff":
        return (("utf-32-be", 4),)
    if data[:4] == b"\xff\xfe\x00\x00":
        return (("utf-32-le", 4),)
    if data[:2] == b"\xfe\xff":
        return (("utf-16-be", 2),)
    if data[:2] == b"\xff\xfe":
        return (("utf-16-le", 2),)
    if data[:3] == b"\xef\xbb\xbf":
        return (("utf-8-sig", 0),)

    # A BOM-less UTF-16/32 declaration is itself NUL-interleaved, so an ASCII
    # declaration regex cannot identify its byte order. Scan both byte orders;
    # the parser-level guard below remains authoritative for the full document.
    if b"\x00" in data[:16]:
        return (
            ("utf-16-le", 0),
            ("utf-16-be", 0),
            ("utf-32-le", 0),
            ("utf-32-be", 0),
        )

    declaration = _XML_DECLARATION_ENCODING.search(data[:256])
    if declaration is None:
        return (("utf-8", 0),)
    try:
        encoding = declaration.group(2).decode("ascii").lower().replace("_", "-")
    except (LookupError, UnicodeError, ValueError):
        return ()
    if encoding not in _ALLOWED_XML_ENCODINGS:
        return ()
    if encoding == "utf-16":
        return (("utf-16-le", 0), ("utf-16-be", 0))
    if encoding == "utf-32":
        return (("utf-32-le", 0), ("utf-32-be", 0))
    return ((encoding, 0),)


class _ForbiddenXmlDeclaration(Exception):
    """Internal signal raised from Expat declaration callbacks."""


def reject_forbidden_xml_declarations(
    data: bytes | str,
    *,
    error_type: type[Exception],
    context: ForbiddenXmlContext = "document",
) -> None:
    """Reject DTD/entity declarations with the caller's public error contract."""
    message = _FORBIDDEN_XML_MESSAGES[context]
    if isinstance(data, str):
        # Python text has already been decoded, so it has no UTF-16 byte-layout
        # hole. This is the guard used by the operation-model validation layer.
        if _FORBIDDEN_XML_TEXT.search(data):
            raise error_type(message)
        return

    # This unconditional whole-document pass covers every single-byte encoding.
    # Decoding below is an additional pass for NUL-interleaved UTF-16/32 input.
    if _FORBIDDEN_XML.search(data):
        raise error_type(message)

    for encoding, bom_len in _encoding_candidates(data):
        try:
            text = data[bom_len:].decode(encoding, errors="replace")
        except (LookupError, UnicodeError, ValueError):
            continue
        if _FORBIDDEN_XML_TEXT.search(text):
            raise error_type(message)

    # Expat callbacks make the final rejection independent of byte position and
    # encoding whenever the input is otherwise parseable by the XML parser.
    parser = expat.ParserCreate(_expat_byte_encoding_hint(data))

    def reject_doctype(
        _doctype_name: str,
        _system_id: str | None,
        _public_id: str | None,
        _has_internal_subset: int,
    ) -> None:
        raise _ForbiddenXmlDeclaration

    def reject_entity(
        _entity_name: str,
        _is_parameter_entity: int,
        _value: str | None,
        _base: str | None,
        _system_id: str | None,
        _public_id: str | None,
        _notation_name: str | None,
    ) -> None:
        raise _ForbiddenXmlDeclaration

    def reject_external_entity(
        _context: str,
        _base: str | None,
        _system_id: str | None,
        _public_id: str | None,
    ) -> int:
        raise _ForbiddenXmlDeclaration

    parser.StartDoctypeDeclHandler = reject_doctype
    parser.EntityDeclHandler = reject_entity
    parser.ExternalEntityRefHandler = reject_external_entity
    try:
        parser.Parse(data, True)
    except _ForbiddenXmlDeclaration:
        raise error_type(message) from None
    except (expat.ExpatError, LookupError, UnicodeError, ValueError):
        # ElementTree below preserves the public Invalid XML error contract for
        # ordinary syntax and unsupported-encoding failures.
        return


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    handle, temporary_name = tempfile.mkstemp(prefix=f".{path.name}.", dir=path.parent)
    temporary_path = Path(temporary_name)
    try:
        with os.fdopen(handle, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_path, path)
    finally:
        temporary_path.unlink(missing_ok=True)


def _parse_root(data: bytes) -> ET.Element:
    reject_forbidden_xml_declarations(data, error_type=DocumentError)
    try:
        source_encoding = _detect_xml_encoding(data)
        parser = ET.XMLParser(
            target=ET.TreeBuilder(insert_comments=True),
            encoding=_expat_encoding_hint(source_encoding.codec),
        )
        return ET.fromstring(data, parser=parser)
    except (ET.ParseError, LookupError, UnicodeError, ValueError) as exc:
        raise DocumentError(f"Invalid XML: {exc}") from exc


def parse_xml_definition(data: str) -> ET.Element:
    """Parse an embedded pattern definition through the shared write guard."""
    reject_forbidden_xml_declarations(
        data,
        error_type=EditError,
        context="pattern_definition",
    )
    try:
        return ET.fromstring(data)
    except (ET.ParseError, ValueError) as exc:
        raise EditError(f"Invalid embedded XML definition: {exc}") from exc


@dataclass(frozen=True)
class XmlEdit:
    operation: EditOperation
    xpath: str
    value: str | None = None
    attribute: str | None = None
    expected_matches: int = 1


@dataclass
class _RawElementSpan:
    name: str
    start: int
    start_tag_end: int
    parent_index: int | None
    self_closing: bool
    content_end: int = -1
    end: int = -1


@dataclass(frozen=True)
class _TreeElementState:
    element: ET.Element
    span_index: int
    tag: str
    attributes: dict[str, str]
    text: str | None
    parent_id: int | None
    child_ids: tuple[int, ...]


@dataclass(frozen=True)
class RawTreeSnapshot:
    """Capture element identity before semantic mutations for raw-preserving compilation."""

    raw_bytes: bytes
    root_id: int
    spans: tuple[_RawElementSpan, ...]
    states: dict[int, _TreeElementState]
    encoding: str

    @classmethod
    def capture(cls, document: DipTraceDocument) -> RawTreeSnapshot:
        spans, mapping = _element_span_map(document)
        states: dict[int, _TreeElementState] = {}

        def visit(element: ET.Element, parent_id: int | None) -> None:
            element_id = id(element)
            children = tuple(
                id(child) for child in element if isinstance(child.tag, str)
            )
            states[element_id] = _TreeElementState(
                element=element,
                span_index=mapping[element_id],
                tag=element.tag,
                attributes=dict(element.attrib),
                text=element.text,
                parent_id=parent_id,
                child_ids=children,
            )
            for child in element:
                if isinstance(child.tag, str):
                    visit(child, element_id)

        visit(document.root, None)
        return cls(
            raw_bytes=document.raw_bytes,
            root_id=id(document.root),
            spans=tuple(spans),
            states=states,
            encoding=document.encoding,
        )

    def compile(self, root: ET.Element, path: Path) -> bytes:
        if id(root) != self.root_id:
            raise EditError("Semantic compiler replaced the XML root")

        current: dict[int, ET.Element] = {}
        parents: dict[int, int | None] = {}
        children: dict[int, tuple[int, ...]] = {}

        def visit(element: ET.Element, parent_id: int | None) -> None:
            element_id = id(element)
            current[element_id] = element
            parents[element_id] = parent_id
            child_ids = tuple(
                id(child) for child in element if isinstance(child.tag, str)
            )
            children[element_id] = child_ids
            for child in element:
                if isinstance(child.tag, str):
                    visit(child, element_id)

        visit(root, None)
        existing = set(self.states) & set(current)
        for element_id in existing:
            state = self.states[element_id]
            element = current[element_id]
            if element.tag != state.tag:
                raise EditError("Semantic compiler changed an existing XML element name")
            if parents[element_id] != state.parent_id:
                raise EditError("Moving existing XML elements between parents is unsupported")

        replaced: set[int] = set()
        for element_id in existing:
            state = self.states[element_id]
            span = self.spans[state.span_index]
            if span.self_closing and (
                state.text != current[element_id].text
                or state.child_ids != children[element_id]
            ):
                replaced.add(element_id)

        def has_replaced_ancestor(element_id: int, *, current_tree: bool) -> bool:
            parent_id = (
                parents.get(element_id)
                if current_tree
                else self.states[element_id].parent_id
            )
            while parent_id is not None:
                if parent_id in replaced:
                    return True
                parent_id = (
                    parents.get(parent_id)
                    if current_tree
                    else self.states[parent_id].parent_id
                )
            return False

        for parent_id in existing - replaced:
            original_survivors = tuple(
                child_id
                for child_id in self.states[parent_id].child_ids
                if child_id in current
            )
            current_existing = tuple(
                child_id
                for child_id in children[parent_id]
                if child_id in self.states
            )
            if original_survivors != current_existing:
                raise EditError("Reordering existing XML siblings is unsupported")

        replacements: list[tuple[int, int, bytes]] = []
        for element_id in sorted(
            replaced,
            key=lambda item: self.spans[self.states[item].span_index].start,
        ):
            if has_replaced_ancestor(element_id, current_tree=True):
                continue
            state = self.states[element_id]
            span = self.spans[state.span_index]
            start_tag = self.raw_bytes[span.start : span.start_tag_end]
            start_tag = _patch_start_tag(
                start_tag,
                state.attributes,
                current[element_id].attrib,
                self.encoding,
            )
            rendered = _open_self_closing_tag(start_tag, self.encoding)
            if current[element_id].text:
                rendered += _escape_xml_text(current[element_id].text or "", self.encoding)
            rendered += b"".join(
                _serialize_new_element(child, self.encoding)
                for child in current[element_id]
                if isinstance(child.tag, str)
            )
            rendered += _encode_xml_fragment(f"</{state.tag}>", self.encoding)
            replacements.append((span.start, span.end, rendered))

        for element_id in existing - replaced:
            if has_replaced_ancestor(element_id, current_tree=True):
                continue
            state = self.states[element_id]
            element = current[element_id]
            span = self.spans[state.span_index]
            start_tag = self.raw_bytes[span.start : span.start_tag_end]
            patched_start_tag = _patch_start_tag(
                start_tag,
                state.attributes,
                element.attrib,
                self.encoding,
            )
            if patched_start_tag != start_tag:
                replacements.append((span.start, span.start_tag_end, patched_start_tag))
            if state.text != element.text:
                direct_children = [
                    child for child in self.spans if child.parent_index == state.span_index
                ]
                text_end = direct_children[0].start if direct_children else span.content_end
                replacements.append(
                    (
                        span.start_tag_end,
                        text_end,
                        _escape_xml_text(element.text or "", self.encoding),
                    )
                )

        for element_id, state in self.states.items():
            if element_id in current or has_replaced_ancestor(element_id, current_tree=False):
                continue
            deleted_parent_id = state.parent_id
            if deleted_parent_id is not None and deleted_parent_id not in current:
                continue
            span = self.spans[state.span_index]
            replacements.append((span.start, span.end, b""))

        insertions: dict[int, list[tuple[int, bytes]]] = {}
        for parent_id in existing - replaced:
            if has_replaced_ancestor(parent_id, current_tree=True):
                continue
            sibling_ids = children[parent_id]
            parent_span = self.spans[self.states[parent_id].span_index]
            for index, child_id in enumerate(sibling_ids):
                if child_id in self.states:
                    continue
                if parents[child_id] not in self.states:
                    continue
                next_existing = next(
                    (
                        candidate
                        for candidate in sibling_ids[index + 1 :]
                        if candidate in self.states
                    ),
                    None,
                )
                offset = (
                    self.spans[self.states[next_existing].span_index].start
                    if next_existing is not None
                    else parent_span.content_end
                )
                insertions.setdefault(offset, []).append(
                    (index, _serialize_new_element(current[child_id], self.encoding))
                )
        for offset, values in insertions.items():
            rendered = b"".join(value for _, value in sorted(values))
            replacements.append((offset, offset, rendered))

        compiled = _apply_replacements(self.raw_bytes, replacements)
        reparsed = DipTraceDocument.from_bytes(path, compiled)
        if _semantic_tree(reparsed.root) != _semantic_tree(root):
            raise EditError(
                "Raw-preserving semantic compilation does not match the mutated XML tree"
            )
        return compiled


@dataclass
class DipTraceDocument:
    path: Path
    root: ET.Element
    raw_bytes: bytes
    encoding: str = "utf-8"
    bom: bytes = b""
    declared_encoding: str | None = None
    _element_byte_offsets: tuple[int, dict[int, int]] | None = field(
        default=None,
        init=False,
        repr=False,
        compare=False,
    )

    @classmethod
    def load(cls, path: Path, max_bytes: int) -> DipTraceDocument:
        try:
            size = path.stat().st_size
        except OSError as exc:
            raise DocumentError(f"Cannot stat document: {path}") from exc
        if size > max_bytes:
            raise DocumentError(f"Document is larger than {max_bytes} bytes: {path}")
        try:
            data = path.read_bytes()
        except OSError as exc:
            raise DocumentError(f"Cannot read document: {path}") from exc
        return cls.from_bytes(path, data)

    @classmethod
    def from_bytes(cls, path: Path, data: bytes) -> DipTraceDocument:
        root = _parse_root(data)
        source_encoding = _detect_xml_encoding(data)
        source_type = root.get("Type", "")
        valid_root = root.tag == "Source" or (
            root.tag == "Library"
            and source_type
            in {"DipTrace-ComponentLibrary", "DipTrace-PatternLibrary"}
        )
        if not valid_root:
            raise DocumentError(f"Expected a DipTrace <Source> or <Library> root, got <{root.tag}>")
        if not source_type.startswith("DipTrace-"):
            raise DocumentError(f"Unsupported DipTrace XML type: {source_type or '<empty>'}")
        return cls(
            path=path,
            root=root,
            raw_bytes=data,
            encoding=source_encoding.codec,
            bom=source_encoding.bom,
            declared_encoding=source_encoding.declared_name,
        )

    @property
    def source_type(self) -> str:
        return self.root.get("Type", "")

    @property
    def version(self) -> str:
        return self.root.get("Version", "")

    @property
    def units(self) -> str:
        return self.root.get("Units", "")

    @property
    def kind(self) -> str:
        lowered = self.source_type.lower()
        if lowered == "diptrace-pcb":
            return "pcb"
        if lowered == "diptrace-schematic":
            return "schematic"
        if "componentlibrary" in lowered:
            return "component_library"
        if "patternlibrary" in lowered:
            return "pattern_library"
        return "generic"

    @property
    def container(self) -> ET.Element:
        if self.kind == "pcb":
            container = self.root.find("./Board")
        elif self.kind == "schematic":
            container = self.root.find("./Schematic")
        else:
            container = self.root
        if container is None:
            raise DocumentError(f"Missing main section for {self.source_type}")
        return container

    @property
    def sha256(self) -> str:
        return sha256_bytes(self.raw_bytes)

    def element_byte_offset(self, element: ET.Element) -> int | None:
        """Return the Expat byte offset for an ElementTree node when available."""

        root_id = id(self.root)
        if self._element_byte_offsets is None or self._element_byte_offsets[0] != root_id:
            offsets: list[int] = []
            parser = expat.ParserCreate()

            def start_element(_name: str, _attributes: dict[str, str]) -> None:
                offsets.append(parser.CurrentByteIndex)

            parser.StartElementHandler = start_element
            try:
                parser.Parse(self.raw_bytes, True)
            except expat.ExpatError:
                return None
            elements = [
                item for item in self.root.iter() if isinstance(item.tag, str)
            ]
            if len(elements) != len(offsets):
                return None
            self._element_byte_offsets = (
                root_id,
                {
                    id(item): offset
                    for item, offset in zip(elements, offsets, strict=True)
                },
            )
        return self._element_byte_offsets[1].get(id(element))

    def _normalize_xpath(self, xpath: str) -> str:
        value = xpath.strip()
        if not value:
            raise EditError("XPath cannot be empty")
        if len(value) > 512:
            raise EditError("XPath is longer than 512 characters")
        if value in {".", "/", "/Source", "Source"}:
            return "."
        if value.startswith("/Source/"):
            return f"./{value[len('/Source/'):]}"
        if value.startswith("Source/"):
            return f"./{value[len('Source/'):]}"
        if value.startswith("//"):
            return f".{value}"
        if value.startswith("/"):
            raise EditError("Absolute XPath must start with /Source")
        if not value.startswith("."):
            return f"./{value}"
        return value

    def findall(self, xpath: str) -> list[ET.Element]:
        normalized = self._normalize_xpath(xpath)
        if normalized == ".":
            return [self.root]
        try:
            return list(self.root.findall(normalized))
        except (KeyError, SyntaxError) as exc:
            raise EditError(f"Unsupported XPath {xpath!r}: {exc}") from exc

    def xml_fragments(self, xpath: str, max_matches: int = 25) -> list[str]:
        matches = self.findall(xpath)
        if len(matches) > max_matches:
            raise DocumentError(
                f"XPath returned {len(matches)} elements; limit is {max_matches}"
            )
        return [ET.tostring(element, encoding="unicode") for element in matches]

    def apply_edits(self, edits: list[XmlEdit]) -> tuple[bytes, list[dict[str, object]]]:
        if not edits:
            raise EditError("At least one edit is required")
        original_type = self.source_type
        working = self.raw_bytes
        previews: list[dict[str, object]] = []

        for index, edit in enumerate(edits):
            if edit.expected_matches <= 0:
                raise EditError(f"Edit {index}: expected_matches must be greater than zero")
            current = DipTraceDocument.from_bytes(self.path, working)
            matches = current.findall(edit.xpath)
            if len(matches) != edit.expected_matches:
                raise EditError(
                    f"Edit {index}: XPath {edit.xpath!r} matched {len(matches)} elements, "
                    f"expected {edit.expected_matches}"
                )
            working = _apply_raw_edit(current, index, edit, matches)
            _apply_expected_tree_edit(current, index, edit, matches)
            updated = DipTraceDocument.from_bytes(self.path, working)
            if _semantic_tree(updated.root) != _semantic_tree(current.root):
                raise EditError(
                    f"Edit {index}: raw XML output does not match the requested semantic edit"
                )
            previews.append(
                {
                    "index": index,
                    "operation": edit.operation,
                    "xpath": edit.xpath,
                    "matches": len(matches),
                    "expected_matches": edit.expected_matches,
                    "before_count": len(matches),
                    "after_count": len(updated.findall(edit.xpath)),
                }
            )

        validated = DipTraceDocument.from_bytes(self.path, working)
        if validated.source_type != original_type:
            raise EditError("The edit changed the DipTrace document type")
        self.root = validated.root
        self.raw_bytes = working
        self.encoding = validated.encoding
        self.bom = validated.bom
        self.declared_encoding = validated.declared_encoding
        return working, previews


def _scan_start_tag_end(data: bytes, start: int, encoding: str) -> int:
    unit_size = (
        4
        if encoding.startswith("utf-32")
        else 2
        if encoding.startswith("utf-16")
        else 1
    )
    quote: bytes | None = None
    double_quote = _encode_xml_fragment('"', encoding)
    single_quote = _encode_xml_fragment("'", encoding)
    closing = _encode_xml_fragment(">", encoding)
    for position in range(start + unit_size, len(data), unit_size):
        value = data[position : position + unit_size]
        if len(value) != unit_size:
            break
        if quote is not None:
            if value == quote:
                quote = None
        elif value in {double_quote, single_quote}:
            quote = value
        elif value == closing:
            return position + unit_size
    raise EditError(f"Unterminated XML start tag at byte {start}")


def _raw_element_spans(data: bytes, encoding: str) -> list[_RawElementSpan]:
    reject_forbidden_xml_declarations(data, error_type=EditError)
    spans: list[_RawElementSpan] = []
    stack: list[int] = []
    parser = expat.ParserCreate(_expat_encoding_hint(encoding))

    def start_element(name: str, _attributes: dict[str, str]) -> None:
        start = parser.CurrentByteIndex
        start_tag_end = _scan_start_tag_end(data, start, encoding)
        start_tag = data[start:start_tag_end]
        self_closing = _decode_xml_fragment(start_tag, encoding).rstrip().endswith("/>")
        parent_index = stack[-1] if stack else None
        spans.append(
            _RawElementSpan(
                name=name,
                start=start,
                start_tag_end=start_tag_end,
                parent_index=parent_index,
                self_closing=self_closing,
            )
        )
        stack.append(len(spans) - 1)

    def end_element(_name: str) -> None:
        if not stack:
            raise EditError("XML span parser encountered an unbalanced end tag")
        span = spans[stack.pop()]
        if span.self_closing:
            span.content_end = span.start_tag_end
            span.end = span.start_tag_end
            return
        closing_start = parser.CurrentByteIndex
        span.content_end = closing_start
        span.end = _scan_start_tag_end(data, closing_start, encoding)

    parser.StartElementHandler = start_element
    parser.EndElementHandler = end_element
    try:
        parser.Parse(data, True)
    except (expat.ExpatError, EditError, LookupError, UnicodeError, ValueError) as exc:
        raise EditError(f"Cannot map XML byte spans: {exc}") from exc
    if stack or any(span.end < 0 for span in spans):
        raise EditError("XML span parser did not close every element")
    return spans


def _element_span_map(document: DipTraceDocument) -> tuple[list[_RawElementSpan], dict[int, int]]:
    spans = _raw_element_spans(document.raw_bytes, document.encoding)
    elements = [element for element in document.root.iter() if isinstance(element.tag, str)]
    if len(elements) != len(spans):
        raise EditError(
            "XML parser disagreement while mapping byte spans: "
            f"ElementTree={len(elements)}, Expat={len(spans)}"
        )
    mapping: dict[int, int] = {}
    for index, (element, span) in enumerate(zip(elements, spans, strict=True)):
        element_name = str(element.tag)
        if element_name != span.name:
            raise EditError(
                "XML parser disagreement while mapping byte spans: "
                f"ElementTree={element_name!r}, Expat={span.name!r}"
            )
        mapping[id(element)] = index
    return spans, mapping


def _patch_start_tag(
    start_tag: bytes,
    before: dict[str, str],
    after: dict[str, str],
    encoding: str,
) -> bytes:
    patched = start_tag
    for name in before:
        if name not in after:
            patched = _remove_raw_attribute(patched, name, encoding)
    for name, value in after.items():
        if before.get(name) != value:
            patched = _set_raw_attribute(patched, name, value, encoding)
    return patched


def _serialize_new_element(element: ET.Element, encoding: str) -> bytes:
    clone = deepcopy(element)
    clone.tail = None
    for descendant in clone.iter():
        if descendant.text:
            _require_valid_xml_characters(descendant.text, "XML element text")
        if descendant.tail:
            _require_valid_xml_characters(descendant.tail, "XML element tail")
        for attribute, value in descendant.attrib.items():
            _require_valid_xml_characters(
                value,
                f"XML attribute {attribute}",
            )
    rendered = ET.tostring(
        clone,
        encoding="unicode",
        short_empty_elements=True,
    )
    # XML normalizes literal carriage returns in text nodes. Attribute controls
    # are already emitted as character references by ElementTree.
    return _encode_xml_fragment(rendered.replace("\r", "&#13;"), encoding)


def _semantic_tree(element: ET.Element) -> tuple[tuple[object, ...], ...]:
    """Build a flat preorder value so comparison is recursion-safe."""

    pending = [element]
    rendered: list[tuple[object, ...]] = []
    while pending:
        current = pending.pop()
        children = list(current)
        text = current.text
        normalized_text = None if text is None or not text.strip() else text
        tail = current.tail
        normalized_tail = None if tail is None or not tail.strip() else tail
        tag = current.tag if isinstance(current.tag, str) else "#comment"
        rendered.append(
  (
      tag,
      tuple(sorted(current.attrib.items())),
      normalized_text,
      normalized_tail,
      len(children),
  )
        )
        pending.extend(reversed(children))
    return tuple(rendered)


def _escape_xml_text(value: str, encoding: str) -> bytes:
    _require_valid_xml_characters(value, "XML text replacement")
    escaped = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    escaped = escaped.replace("\t", "&#9;").replace("\n", "&#10;").replace("\r", "&#13;")
    return _encode_xml_fragment(escaped, encoding)


def _escape_xml_attribute(value: str, quote: str) -> str:
    _require_valid_xml_characters(value, "XML attribute replacement")
    escaped = value.replace("&", "&amp;").replace("<", "&lt;")
    escaped = escaped.replace('"', "&quot;") if quote == '"' else escaped.replace("'", "&apos;")
    return escaped.replace("\t", "&#9;").replace("\n", "&#10;").replace("\r", "&#13;")


def _require_valid_xml_characters(value: str, context: str) -> None:
    match = _INVALID_XML_10_CHARACTER.search(value)
    if match is None:
        return
    code_point = ord(match.group())
    raise EditError(
        f"{context} contains XML 1.0-forbidden character U+{code_point:04X} "
        f"at character offset {match.start()}",
        details={
            "context": context,
            "character_offset": match.start(),
            "code_point": f"U+{code_point:04X}",
        },
    )


def _attribute_match(start_tag: str, name: str) -> re.Match[str] | None:
    encoded = re.escape(name)
    pattern = re.compile(
        r"(?P<leading>\s)"
        + encoded
        + r"(?P<equals>\s*=\s*)(?P<quote>[\"'])(?P<value>.*?)(?P=quote)",
        re.DOTALL,
    )
    return pattern.search(start_tag)


def _set_raw_attribute(start_tag: bytes, name: str, value: str, encoding: str) -> bytes:
    if not _XML_NAME.fullmatch(name):
        raise EditError(f"Invalid XML attribute name: {name!r}")
    decoded = _decode_xml_fragment(start_tag, encoding)
    match = _attribute_match(decoded, name)
    if match is not None:
        quote = match.group("quote")
        replacement = (
            match.group("leading")
            + name
            + match.group("equals")
            + quote
            + _escape_xml_attribute(value, quote)
            + quote
        )
        decoded = decoded[: match.start()] + replacement + decoded[match.end() :]
        return _encode_xml_fragment(decoded, encoding)
    insert_at = len(decoded) - 1
    if decoded[:insert_at].rstrip().endswith("/"):
        insert_at = decoded.rfind("/", 0, insert_at)
    addition = " " + name + '="' + _escape_xml_attribute(value, '"') + '"'
    return _encode_xml_fragment(decoded[:insert_at] + addition + decoded[insert_at:], encoding)


def _remove_raw_attribute(start_tag: bytes, name: str, encoding: str) -> bytes:
    if not _XML_NAME.fullmatch(name):
        raise EditError(f"Invalid XML attribute name: {name!r}")
    decoded = _decode_xml_fragment(start_tag, encoding)
    match = _attribute_match(decoded, name)
    if match is None:
        raise EditError(f"XML attribute {name!r} is missing")
    leading = match.group("leading")
    preserved = leading if leading in {"\r", "\n"} else ""
    return _encode_xml_fragment(
        decoded[: match.start()] + preserved + decoded[match.end() :],
        encoding,
    )


def _open_self_closing_tag(start_tag: bytes, encoding: str) -> bytes:
    decoded = _decode_xml_fragment(start_tag, encoding)
    closing = decoded.rfind("/")
    if closing < 0:
        raise EditError("Expected a self-closing XML tag")
    return _encode_xml_fragment(decoded[:closing].rstrip() + ">", encoding)


def _apply_replacements(data: bytes, replacements: list[tuple[int, int, bytes]]) -> bytes:
    ordered = sorted(replacements, key=lambda item: (item[0], item[1]), reverse=True)
    previous_start = len(data) + 1
    for start, end, replacement in ordered:
        if not (0 <= start <= end <= len(data)):
            raise EditError("XML byte replacement is outside the document")
        if end > previous_start:
            raise EditError("Overlapping XML byte replacements are ambiguous")
        data = data[:start] + replacement + data[end:]
        previous_start = start
    return data


def _apply_raw_edit(
    document: DipTraceDocument,
    index: int,
    edit: XmlEdit,
    matches: list[ET.Element],
) -> bytes:
    spans, mapping = _element_span_map(document)
    replacements: list[tuple[int, int, bytes]] = []
    if edit.operation in {"replace_xml", "delete_element"} and any(
        element is document.root for element in matches
    ):
        raise EditError(f"Edit {index}: replacing or deleting <Source> is forbidden")

    if edit.operation == "set_text" and edit.value is None:
        raise EditError(f"Edit {index}: set_text requires value")
    if edit.operation == "set_attribute" and (not edit.attribute or edit.value is None):
        raise EditError(f"Edit {index}: set_attribute requires attribute and value")
    if edit.operation == "remove_attribute" and not edit.attribute:
        raise EditError(f"Edit {index}: remove_attribute requires attribute")
    fragment: bytes | None = None
    if edit.operation in {"append_xml", "replace_xml"}:
        _parse_fragment(index, edit.value)
        assert edit.value is not None
        fragment = _encode_xml_fragment(edit.value.strip(), document.encoding)

    for element in matches:
        span_index = mapping[id(element)]
        span = spans[span_index]
        start_tag = document.raw_bytes[span.start : span.start_tag_end]
        if edit.operation == "set_text":
            assert edit.value is not None
            escaped = _escape_xml_text(edit.value, document.encoding)
            if span.self_closing:
                replacement = _open_self_closing_tag(start_tag, document.encoding) + escaped
                replacement += _encode_xml_fragment(f"</{span.name}>", document.encoding)
                replacements.append((span.start, span.end, replacement))
            else:
                direct_children = [
                    child for child in spans if child.parent_index == span_index
                ]
                text_end = direct_children[0].start if direct_children else span.content_end
                replacements.append((span.start_tag_end, text_end, escaped))
        elif edit.operation == "set_attribute":
            assert edit.attribute is not None and edit.value is not None
            replacements.append(
                (
                    span.start,
                    span.start_tag_end,
                    _set_raw_attribute(
                        start_tag,
                        edit.attribute,
                        edit.value,
                        document.encoding,
                    ),
                )
            )
        elif edit.operation == "remove_attribute":
            assert edit.attribute is not None
            replacements.append(
                (
                    span.start,
                    span.start_tag_end,
                    _remove_raw_attribute(start_tag, edit.attribute, document.encoding),
                )
            )
        elif edit.operation == "append_xml":
            assert fragment is not None
            if span.self_closing:
                replacement = _open_self_closing_tag(start_tag, document.encoding) + fragment
                replacement += _encode_xml_fragment(f"</{span.name}>", document.encoding)
                replacements.append((span.start, span.end, replacement))
            else:
                replacements.append((span.content_end, span.content_end, fragment))
        elif edit.operation == "replace_xml":
            assert fragment is not None
            replacements.append((span.start, span.end, fragment))
        elif edit.operation == "delete_element":
            replacements.append((span.start, span.end, b""))
        else:
            raise EditError(f"Edit {index}: unsupported operation {edit.operation!r}")

    return _apply_replacements(document.raw_bytes, replacements)


def _apply_expected_tree_edit(
    document: DipTraceDocument,
    index: int,
    edit: XmlEdit,
    matches: list[ET.Element],
) -> None:
    """Apply the requested mutation to the parsed tree for an independent equality gate."""

    if edit.operation == "set_text":
        assert edit.value is not None
        for element in matches:
            element.text = edit.value
        return
    if edit.operation == "set_attribute":
        assert edit.attribute is not None and edit.value is not None
        for element in matches:
            element.set(edit.attribute, edit.value)
        return
    if edit.operation == "remove_attribute":
        assert edit.attribute is not None
        for element in matches:
            element.attrib.pop(edit.attribute)
        return

    fragment = (
        _parse_fragment(index, edit.value)
        if edit.operation in {"append_xml", "replace_xml"}
        else None
    )
    if edit.operation == "append_xml":
        assert fragment is not None
        for element in matches:
            element.append(deepcopy(fragment))
        return

    parents = {
        id(child): parent
        for parent in document.root.iter()
        for child in parent
        if isinstance(child.tag, str)
    }
    for element in matches:
        parent = parents.get(id(element))
        if parent is None:
            raise EditError(f"Edit {index}: cannot mutate the XML root")
        child_index = list(parent).index(element)
        if edit.operation == "replace_xml":
            assert fragment is not None
            replacement = deepcopy(fragment)
            replacement.tail = element.tail
            parent.remove(element)
            parent.insert(child_index, replacement)
        elif edit.operation == "delete_element":
            parent.remove(element)
        else:
            raise EditError(f"Edit {index}: unsupported operation {edit.operation!r}")


def _parse_fragment(index: int, value: str | None) -> ET.Element:
    if not value:
        raise EditError(f"Edit {index}: XML fragment is required")
    _require_valid_xml_characters(value, f"Edit {index} XML fragment")
    wrapper = _parse_root_fragment(value.encode("utf-8"))
    children = list(wrapper)
    if (
        len(children) != 1
        or not isinstance(children[0].tag, str)
        or (wrapper.text and wrapper.text.strip())
        or (children[0].tail and children[0].tail.strip())
    ):
        raise EditError(f"Edit {index}: XML fragment must contain exactly one root element")
    root = children[0]
    if any(
        cast(object, element.tag) is cast(object, ET.ProcessingInstruction)
        for element in root.iter()
    ):
        raise EditError(f"Edit {index}: XML processing instructions are not supported in fragments")
    return root


def _parse_root_fragment(data: bytes) -> ET.Element:
    reject_forbidden_xml_declarations(
        data,
        error_type=EditError,
        context="fragment",
    )
    try:
        parser = ET.XMLParser(
            target=ET.TreeBuilder(insert_comments=True, insert_pis=True),
        )
        return ET.fromstring(
            b"<McpFragment>" + data + b"</McpFragment>",
            parser=parser,
        )
    except ET.ParseError as exc:
        raise EditError(f"Invalid XML fragment: {exc}") from exc


DEFAULT_DIFF_LINE_LIMIT = 200
DEFAULT_DIFF_CHARACTER_LIMIT = 200_000
_DIFF_TRUNCATION_MARKER = "... diff truncated; see metadata for total size ..."


def unified_xml_diff_preview(
    before: bytes,
    after: bytes,
    max_lines: int = DEFAULT_DIFF_LINE_LIMIT,
    max_characters: int = DEFAULT_DIFF_CHARACTER_LIMIT,
) -> tuple[str, dict[str, int | bool]]:
    """Return a prefix bounded by both stored lines and stored characters."""

    if max_lines < 1:
        raise ValueError("max_lines must be positive")
    if max_characters < len(_DIFF_TRUNCATION_MARKER):
        raise ValueError(
            "max_characters must be large enough for the truncation disclosure"
        )
    before_encoding = _detect_xml_encoding(before)
    after_encoding = _detect_xml_encoding(after)
    before_body = (
        before[len(before_encoding.bom) :]
        if before_encoding.bom and before.startswith(before_encoding.bom)
        else before
    )
    after_body = (
        after[len(after_encoding.bom) :]
        if after_encoding.bom and after.startswith(after_encoding.bom)
        else after
    )
    before_lines = before_body.decode(before_encoding.codec, errors="replace").splitlines()
    after_lines = after_body.decode(after_encoding.codec, errors="replace").splitlines()
    diff_lines = difflib.unified_diff(
        before_lines,
        after_lines,
        fromfile="before.xml",
        tofile="after.xml",
        lineterm="",
    )
    stored_lines: list[str] = []
    stored_characters = 0
    total_line_count = 0
    total_character_count = 0
    prefix_open = True
    for line in diff_lines:
        if total_line_count:
            total_character_count += 1
        total_line_count += 1
        total_character_count += len(line)
        additional_characters = len(line) + (1 if stored_lines else 0)
        if (
            prefix_open
            and len(stored_lines) < max_lines
            and stored_characters + additional_characters <= max_characters
        ):
            stored_lines.append(line)
            stored_characters += additional_characters
        else:
            prefix_open = False

    truncated = (
        len(stored_lines) < total_line_count
        or stored_characters < total_character_count
    )
    if truncated:
        while stored_lines and (
            len(stored_lines) + 1 > max_lines
            or stored_characters
            + 1
            + len(_DIFF_TRUNCATION_MARKER)
            > max_characters
        ):
            removed = stored_lines.pop()
            stored_characters -= len(removed)
            if stored_lines:
                stored_characters -= 1
        marker_separator = 1 if stored_lines else 0
        stored_lines.append(_DIFF_TRUNCATION_MARKER)
        stored_characters += marker_separator + len(_DIFF_TRUNCATION_MARKER)

    rendered = "\n".join(stored_lines)
    metadata: dict[str, int | bool] = {
        "truncated": truncated,
        "truncated_by_lines": total_line_count > max_lines,
        "truncated_by_characters": total_character_count > max_characters,
        "line_limit": max_lines,
        "character_limit": max_characters,
        "total_line_count": total_line_count,
        "total_character_count": total_character_count,
        "stored_line_count": len(stored_lines),
        "stored_character_count": len(rendered),
    }
    return rendered, metadata


def unified_xml_diff(
    before: bytes,
    after: bytes,
    max_lines: int = DEFAULT_DIFF_LINE_LIMIT,
    max_characters: int = DEFAULT_DIFF_CHARACTER_LIMIT,
) -> str:
    diff, _ = unified_xml_diff_preview(
        before,
        after,
        max_lines=max_lines,
        max_characters=max_characters,
    )
    return diff


class BackupWriter(Protocol):
    def write_with_backup(
        self,
        path: Path,
        data: bytes,
        *,
        expected_sha256: str | None = None,
    ) -> Path: ...


def write_with_backup(
    path: Path,
    data: bytes,
    destination: BackupWriter,
    *,
    expected_sha256: str | None = None,
) -> Path:
    if isinstance(destination, Path):
        raise EditError(
            "Writes require a retention-managed backup writer",
            code="backup_manager_required",
        )
    return destination.write_with_backup(
        path,
        data,
        expected_sha256=expected_sha256,
    )
