from __future__ import annotations

import json
import os
import re
import subprocess
import sys
import threading
import time
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import Settings
from .domain import DocumentInfo, FieldSolverRequest, FieldSolverResult, JobRecord
from .errors import (
    DipTraceMcpError,
    ExternalToolFailedError,
    ExternalToolUnavailableError,
    JobCancelledError,
    JobTimeoutError,
)
from .external_process import (
    ExternalProcessReservation,
    ExternalProcessRunner,
)
from .jobs import JobStore, job_resources
from .xml_document import sha256_bytes, utc_now

_NET_CLASS = re.compile(r"^[A-Za-z0-9_.:+/ -]{1,128}$")


@dataclass(frozen=True, slots=True)
class FreeroutingProbe:
    available: bool
    mode: str | None
    executable: str | None
    java: str | None
    reason: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "mode": self.mode,
            "executable": self.executable,
            "java": self.java,
            "reason": self.reason,
            "cli_contract": "Freerouting -de input.dsn -do output.ses --gui.enabled=false",
        }


class FreeroutingAdapter:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def probe(self) -> FreeroutingProbe:
        executable = self.settings.freerouting_executable
        if executable is None:
            return FreeroutingProbe(
                False,
                None,
                None,
                str(self.settings.java_executable) if self.settings.java_executable else None,
                "DIPTRACE_MCP_FREEROUTING is not configured.",
            )
        if not executable.is_file():
            return FreeroutingProbe(
                False,
                None,
                str(executable),
                str(self.settings.java_executable) if self.settings.java_executable else None,
                "Configured Freerouting executable does not exist.",
            )
        if executable.suffix.casefold() == ".jar":
            java = self.settings.java_executable
            if java is None or not java.is_file():
                return FreeroutingProbe(
                    False,
                    "jar",
                    str(executable),
                    str(java) if java else None,
                    "A Java executable is required for the configured Freerouting JAR.",
                )
            return FreeroutingProbe(True, "jar", str(executable), str(java), None)
        if os.name != "nt" and not os.access(executable, os.X_OK):
            return FreeroutingProbe(
                False, "native", str(executable), None, "Configured executable is not executable."
            )
        return FreeroutingProbe(True, "native", str(executable), None, None)

    def command(
        self,
        input_path: Path,
        output_path: Path,
        *,
        max_passes: int,
        threads: int,
        ignore_net_classes: list[str],
    ) -> list[str]:
        if not 1 <= max_passes <= 10_000:
            raise ExternalToolFailedError("max_passes must be between 1 and 10000")
        if not 1 <= threads <= 64:
            raise ExternalToolFailedError("threads must be between 1 and 64")
        if len(ignore_net_classes) > 100 or any(
            not _NET_CLASS.fullmatch(item) for item in ignore_net_classes
        ):
            raise ExternalToolFailedError("Invalid ignore_net_classes value")
        probe = self.probe()
        if not probe.available or probe.executable is None:
            raise ExternalToolUnavailableError(
                probe.reason or "Freerouting is unavailable", details=probe.as_dict()
            )
        prefix = (
            [probe.java or "", "-jar", probe.executable]
            if probe.mode == "jar"
            else [probe.executable]
        )
        command = [
            *prefix,
            "-de",
            str(input_path),
            "-do",
            str(output_path),
            "-mp",
            str(max_passes),
            "-mt",
            str(threads),
            "--gui.enabled=false",
        ]
        if ignore_net_classes:
            command.extend(["-inc", ",".join(ignore_net_classes)])
        return command


@dataclass(frozen=True, slots=True)
class NgSpiceProbe:
    available: bool
    executable: str | None
    reason: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "executable": self.executable,
            "reason": self.reason,
            "cli_contract": "ngspice -b input.cir (batch mode, log on stdout)",
        }


class NgSpiceAdapter:
    """Bounded ngspice batch adapter for user-supplied netlists."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def probe(self) -> NgSpiceProbe:
        executable = self.settings.ngspice_executable
        if executable is None:
            return NgSpiceProbe(
                False, None, "DIPTRACE_MCP_NGSPICE is not configured and ngspice is not on PATH."
            )
        if not executable.is_file():
            return NgSpiceProbe(
                False, str(executable), "Configured ngspice executable does not exist."
            )
        if (
            executable.suffix.casefold() != ".py"
            and os.name != "nt"
            and not os.access(executable, os.X_OK)
        ):
            return NgSpiceProbe(False, str(executable), "Configured executable is not executable.")
        return NgSpiceProbe(True, str(executable), None)

    def command(self, netlist_path: Path) -> list[str]:
        probe = self.probe()
        if not probe.available or probe.executable is None:
            raise ExternalToolUnavailableError(
                probe.reason or "ngspice is unavailable", details=probe.as_dict()
            )
        prefix = (
            [sys.executable, probe.executable]
            if Path(probe.executable).suffix.casefold() == ".py"
            else [probe.executable]
        )
        return [*prefix, "-b", str(netlist_path)]


@dataclass(frozen=True, slots=True)
class OpenEmsProbe:
    available: bool
    runner: str | None
    reason: str | None

    def as_dict(self) -> dict[str, Any]:
        return {
            "available": self.available,
            "implemented": True,
            "runner": self.runner,
            "reason": self.reason,
            "backend": "openems",
            "protocol": "diptrace-field-solver-request/result-v1",
            "cli_contract": "openems-runner --input request.json --output result.json",
            "license_note": "openEMS is GPL-3.0-or-later; configure a compatible runner.",
        }


class OpenEmsAdapter:
    """Fixed-contract adapter for an openEMS-backed stripline runner."""

    def __init__(self, settings: Settings) -> None:
        self.settings = settings

    def probe(self) -> OpenEmsProbe:
        runner = self.settings.openems_runner
        if runner is None:
            return OpenEmsProbe(
                False,
                None,
                "DIPTRACE_MCP_OPENEMS_RUNNER is not configured.",
            )
        if not runner.is_file():
            return OpenEmsProbe(False, str(runner), "Configured openEMS runner does not exist.")
        if runner.suffix.casefold() != ".py" and os.name != "nt" and not os.access(runner, os.X_OK):
            return OpenEmsProbe(False, str(runner), "Configured openEMS runner is not executable.")
        return OpenEmsProbe(True, str(runner), None)

    def command(self, input_path: Path, output_path: Path) -> list[str]:
        probe = self.probe()
        if not probe.available or probe.runner is None:
            raise ExternalToolUnavailableError(
                probe.reason or "openEMS runner is unavailable", details=probe.as_dict()
            )
        prefix = (
            [sys.executable, probe.runner]
            if Path(probe.runner).suffix.casefold() == ".py"
            else [probe.runner]
        )
        return [*prefix, "--input", str(input_path), "--output", str(output_path)]


def parse_field_solver_result(
    payload: bytes,
    request: FieldSolverRequest,
) -> FieldSolverResult:
    """Validate an openEMS runner result and bind it to the requested sweep."""

    try:
        result = FieldSolverResult.model_validate_json(payload)
    except ValueError as exc:
        raise ExternalToolFailedError(
            "openEMS runner returned malformed result JSON",
            details={"validation_error": str(exc)},
        ) from exc
    if not result.converged:
        raise ExternalToolFailedError(
            "openEMS runner reported a non-converged solution",
            details={"solver_version": result.solver_version, "warnings": result.warnings},
        )
    actual = [point.frequency_hz for point in result.points]
    expected = request.frequencies_hz
    if len(actual) != len(expected) or any(
        abs(left - right) > max(1e-6, abs(right) * 1e-9)
        for left, right in zip(actual, expected, strict=True)
    ):
        raise ExternalToolFailedError(
            "openEMS result frequency sweep does not match the request",
            details={"expected_frequencies_hz": expected, "actual_frequencies_hz": actual},
        )
    return result


_DATA_ROWS = re.compile(r"No\.\s*of\s*Data\s*Rows\s*:\s*(\d+)", re.IGNORECASE)
_NGSPICE_ERROR = re.compile(r"^\s*(?:Error|Fatal error).*$", re.IGNORECASE | re.MULTILINE)


def parse_ngspice_log(log: bytes, *, max_errors: int = 50) -> dict[str, Any]:
    """Extract a typed summary from an ngspice batch log."""

    text = log.decode("utf-8", errors="replace")
    data_rows = [int(value) for value in _DATA_ROWS.findall(text)]
    errors = [line.strip() for line in _NGSPICE_ERROR.findall(text)][:max_errors]
    return {
        "data_rows": data_rows,
        "error_lines": errors,
        "log_size_bytes": len(log),
    }


class ExternalJobManager:
    def __init__(self, settings: Settings, store: JobStore) -> None:
        self.settings = settings
        self.store = store
        self.freerouting = FreeroutingAdapter(settings)
        self.ngspice = NgSpiceAdapter(settings)
        self.openems = OpenEmsAdapter(settings)
        self._runner = ExternalProcessRunner(
            max_concurrent=settings.max_external_processes,
            max_log_bytes=settings.max_external_log_bytes,
        )
        self._processes: dict[str, subprocess.Popen[bytes]] = {}
        self._cancel: dict[str, threading.Event] = {}
        self._lock = threading.RLock()

    def create_export_job(
        self,
        info: DocumentInfo,
        target_path: Path,
        dsn: bytes,
        *,
        manifest: dict[str, Any],
    ) -> JobRecord:
        record = self.store.create(
            job_type="dsn_export",
            document_id=info.document_id,
            source_sha256=info.sha256,
            target_path=target_path,
        )
        try:
            self.store.store_artifact(record.jobid, "input.dsn", dsn)
            self.store.store_artifact(
                record.jobid,
                "manifest.json",
                json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"),
            )
            return self.store.update(
                record.jobid,
                status="completed",
                phase="exported",
                progress=1.0,
                started_at=record.created_at,
                completed_at=utc_now(),
                artifacts={
                    "dsn": f"diptrace://job/{record.jobid}/input.dsn",
                    "manifest": f"diptrace://job/{record.jobid}/manifest.json",
                },
                result={"dsn_sha256": sha256_bytes(dsn), "size_bytes": len(dsn)},
            )
        except Exception as exc:
            self._record_setup_failure(record, exc)
            raise

    def start_freerouting(
        self,
        info: DocumentInfo,
        target_path: Path,
        dsn: bytes,
        *,
        max_passes: int,
        threads: int,
        timeout_seconds: int | None,
        ignore_net_classes: list[str],
    ) -> JobRecord:
        probe = self.freerouting.probe()
        if not probe.available:
            raise ExternalToolUnavailableError(
                probe.reason or "Freerouting is unavailable", details=probe.as_dict()
            )
        timeout = timeout_seconds or self.settings.external_timeout_seconds
        if not 1 <= timeout <= self.settings.external_timeout_seconds:
            raise ExternalToolFailedError(
                f"timeout_seconds must be between 1 and {self.settings.external_timeout_seconds}"
            )
        record = self.store.create(
            job_type="freerouting",
            document_id=info.document_id,
            source_sha256=info.sha256,
            target_path=target_path,
        )
        try:
            input_path = self.store.store_artifact(record.jobid, "input.dsn", dsn)
            output_path = self.store.artifact_path(record.jobid, "output.ses")
            command = self.freerouting.command(
                input_path,
                output_path,
                max_passes=max_passes,
                threads=threads,
                ignore_net_classes=ignore_net_classes,
            )
            manifest = {
                "adapter": "freerouting",
                "document_id": info.document_id,
                "source_sha256": info.sha256,
                "dsn_sha256": sha256_bytes(dsn),
                "options": {
                    "max_passes": max_passes,
                    "threads": threads,
                    "timeout_seconds": timeout,
                    "ignore_net_classes": ignore_net_classes,
                },
            }
            self.store.store_artifact(
                record.jobid,
                "manifest.json",
                json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"),
            )
            record = self.store.update(
                record.jobid,
                command=command,
                artifacts={
                    "dsn": f"diptrace://job/{record.jobid}/input.dsn",
                    "manifest": f"diptrace://job/{record.jobid}/manifest.json",
                },
            )
        except Exception as exc:
            self._record_setup_failure(record, exc)
            raise
        return self._launch_worker(
            record,
            target=self._run,
            args=(record.jobid, command, output_path, timeout),
        )

    def start_ngspice(
        self,
        info: DocumentInfo | None,
        target_path: Path | None,
        netlist: bytes,
        *,
        timeout_seconds: int | None,
    ) -> JobRecord:
        probe = self.ngspice.probe()
        if not probe.available:
            raise ExternalToolUnavailableError(
                probe.reason or "ngspice is unavailable", details=probe.as_dict()
            )
        if not netlist.strip():
            raise ExternalToolFailedError("The ngspice netlist is empty")
        timeout = timeout_seconds or self.settings.external_timeout_seconds
        if not 1 <= timeout <= self.settings.external_timeout_seconds:
            raise ExternalToolFailedError(
                f"timeout_seconds must be between 1 and {self.settings.external_timeout_seconds}"
            )
        record = self.store.create(
            job_type="ngspice",
            document_id=info.document_id if info is not None else None,
            source_sha256=info.sha256 if info is not None else None,
            target_path=target_path,
        )
        try:
            input_path = self.store.store_artifact(record.jobid, "input.cir", netlist)
            command = self.ngspice.command(input_path)
            manifest = {
                "adapter": "ngspice",
                "document_id": info.document_id if info is not None else None,
                "source_sha256": info.sha256 if info is not None else None,
                "netlist_sha256": sha256_bytes(netlist),
                "options": {"timeout_seconds": timeout},
            }
            self.store.store_artifact(
                record.jobid,
                "manifest.json",
                json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"),
            )
            record = self.store.update(
                record.jobid,
                command=command,
                artifacts={
                    "netlist": f"diptrace://job/{record.jobid}/input.cir",
                    "manifest": f"diptrace://job/{record.jobid}/manifest.json",
                },
            )
        except Exception as exc:
            self._record_setup_failure(record, exc)
            raise
        return self._launch_worker(
            record,
            target=self._run_ngspice,
            args=(record.jobid, command, timeout),
        )

    def start_openems(
        self,
        info: DocumentInfo | None,
        target_path: Path | None,
        request: FieldSolverRequest,
        *,
        timeout_seconds: int | None,
    ) -> JobRecord:
        probe = self.openems.probe()
        if not probe.available:
            raise ExternalToolUnavailableError(
                probe.reason or "openEMS runner is unavailable", details=probe.as_dict()
            )
        timeout = timeout_seconds or self.settings.external_timeout_seconds
        if not 1 <= timeout <= self.settings.external_timeout_seconds:
            raise ExternalToolFailedError(
                f"timeout_seconds must be between 1 and {self.settings.external_timeout_seconds}"
            )
        record = self.store.create(
            job_type="openems_stripline",
            document_id=info.document_id if info is not None else None,
            source_sha256=info.sha256 if info is not None else None,
            target_path=target_path,
        )
        try:
            input_bytes = request.model_dump_json(indent=2).encode("utf-8")
            input_path = self.store.store_artifact(
                record.jobid,
                "field_solver_input.json",
                input_bytes,
            )
            output_path = self.store.artifact_path(record.jobid, "field_solver_result.json")
            command = self.openems.command(input_path, output_path)
            manifest = {
                "adapter": "openems",
                "protocol": request.schema_version,
                "document_id": info.document_id if info is not None else None,
                "source_sha256": info.sha256 if info is not None else None,
                "request_sha256": sha256_bytes(input_bytes),
                "options": {"timeout_seconds": timeout},
            }
            self.store.store_artifact(
                record.jobid,
                "manifest.json",
                json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True).encode("utf-8"),
            )
            record = self.store.update(
                record.jobid,
                command=command,
                artifacts={
                    "input": f"diptrace://job/{record.jobid}/field_solver_input.json",
                    "manifest": f"diptrace://job/{record.jobid}/manifest.json",
                },
            )
        except Exception as exc:
            self._record_setup_failure(record, exc)
            raise
        return self._launch_worker(
            record,
            target=self._run_openems,
            args=(record.jobid, command, output_path, request, timeout),
        )

    def _launch_worker(
        self,
        record: JobRecord,
        *,
        target: Callable[..., None],
        args: tuple[Any, ...],
    ) -> JobRecord:
        with self._lock:
            current = self.store.read(record.jobid)
            if current.status in {"completed", "failed", "cancelled"}:
                return current
            if current.phase == "cancelling":
                return self.store.update(
                    record.jobid,
                    status="cancelled",
                    phase="cancelled",
                    completed_at=utc_now(),
                    error=JobCancelledError(
                        "External job was cancelled before launch",
                        jobid=record.jobid,
                    ).payload.as_dict(),
                )
            try:
                reservation = self._runner.reserve(jobid=record.jobid)
            except ExternalToolFailedError as exc:
                self.store.update(
                    record.jobid,
                    status="failed",
                    phase="failed",
                    completed_at=utc_now(),
                    error=exc.payload.as_dict(),
                )
                raise
            try:
                cancel = threading.Event()
                thread = threading.Thread(
                    target=target,
                    args=(*args, cancel, reservation),
                    name=f"diptrace-{record.jobid}",
                    daemon=True,
                )
                self._cancel[record.jobid] = cancel
                thread.start()
            except Exception as exc:
                reservation.release()
                self._cancel.pop(record.jobid, None)
                error = ExternalToolFailedError(
                    f"Could not start external job worker: {exc}",
                    jobid=record.jobid,
                )
                self.store.update(
                    record.jobid,
                    status="failed",
                    phase="failed",
                    completed_at=utc_now(),
                    error=error.payload.as_dict(),
                )
                raise error from exc
        return self.store.read(record.jobid)

    def _record_setup_failure(self, record: JobRecord, exc: Exception) -> None:
        current = self.store.read(record.jobid)
        if current.status in {"completed", "failed", "cancelled"}:
            return
        error = (
            exc
            if isinstance(exc, DipTraceMcpError)
            else ExternalToolFailedError(
                f"Could not prepare external job: {exc}",
                jobid=record.jobid,
            )
        )
        self.store.update(
            record.jobid,
            status="failed",
            phase="failed",
            completed_at=utc_now(),
            error=error.payload.as_dict(),
        )

    def cancel(self, jobid: str) -> JobRecord:
        with self._lock:
            record = self.store.read(jobid)
            if record.status in {"completed", "failed", "cancelled"}:
                return record
            event = self._cancel.get(jobid)
            if event is None:
                return self.store.update(
                    jobid,
                    status="cancelled",
                    phase="cancelled",
                    completed_at=utc_now(),
                    error=JobCancelledError(
                        "External job was cancelled before launch",
                        jobid=jobid,
                    ).payload.as_dict(),
                )
            event.set()
            return self.store.update(jobid, phase="cancelling")

    @staticmethod
    def _allowed_environment() -> dict[str, str]:
        return {
            key: value
            for key, value in os.environ.items()
            if key in {"PATH", "HOME", "LANG", "LC_ALL", "SYSTEMROOT", "TEMP", "TMP"}
        }

    def _track_process(self, jobid: str, process: subprocess.Popen[bytes]) -> None:
        with self._lock:
            self._processes[jobid] = process

    def _update_external_progress(self, jobid: str, elapsed: float) -> None:
        self.store.update(jobid, elapsed_seconds=elapsed, progress=0.1)

    def _run(
        self,
        jobid: str,
        command: list[str],
        output_path: Path,
        timeout: int,
        cancel: threading.Event,
        reservation: ExternalProcessReservation,
    ) -> None:
        started = time.monotonic()
        log_path = self.store.artifact_path(jobid, "log.txt")
        try:
            self.store.update(
                jobid,
                status="running",
                phase="external_execution",
                progress=0.05,
                started_at=utc_now(),
            )
            process_result = self._runner.run(
                reservation,
                command,
                cwd=self.store.job_dir(jobid),
                env=self._allowed_environment(),
                log_path=log_path,
                timeout_seconds=timeout,
                cancel=cancel,
                jobid=jobid,
                cancellation_message="External autorouter job was cancelled",
                timeout_message=f"External autorouter exceeded {timeout} seconds",
                on_started=lambda process: self._track_process(jobid, process),
                on_progress=lambda elapsed: self._update_external_progress(jobid, elapsed),
            )
            return_code = process_result.return_code
            elapsed = process_result.elapsed_seconds
            if return_code != 0:
                raise ExternalToolFailedError(
                    f"Freerouting exited with status {return_code}",
                    details={"return_code": return_code},
                    jobid=jobid,
                )
            if not output_path.is_file() or output_path.stat().st_size == 0:
                raise ExternalToolFailedError(
                    "Freerouting did not produce a non-empty SES file", jobid=jobid
                )
            if output_path.stat().st_size > self.settings.max_document_bytes:
                raise ExternalToolFailedError("Freerouting SES output exceeds the size limit")
            self.store.update(
                jobid,
                status="completed",
                phase="completed",
                progress=1.0,
                elapsed_seconds=elapsed,
                completed_at=utc_now(),
                artifacts={
                    **self.store.read(jobid).artifacts,
                    "ses": f"diptrace://job/{jobid}/output.ses",
                    "log": f"diptrace://job/{jobid}/log",
                },
                result={
                    "return_code": return_code,
                    "ses_size_bytes": output_path.stat().st_size,
                    "ses_sha256": sha256_bytes(output_path.read_bytes()),
                    "resources": job_resources(jobid),
                },
            )
        except (JobCancelledError, JobTimeoutError, ExternalToolFailedError) as exc:
            status = "cancelled" if isinstance(exc, JobCancelledError) else "failed"
            self.store.update(
                jobid,
                status=status,
                phase=status,
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=exc.payload.as_dict(),
            )
        except Exception as exc:
            self.store.update(
                jobid,
                status="failed",
                phase="failed",
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=ExternalToolFailedError(
                    f"Could not execute Freerouting: {exc}", jobid=jobid
                ).payload.as_dict(),
            )
        finally:
            reservation.release()
            with self._lock:
                self._processes.pop(jobid, None)
                self._cancel.pop(jobid, None)

    def _run_ngspice(
        self,
        jobid: str,
        command: list[str],
        timeout: int,
        cancel: threading.Event,
        reservation: ExternalProcessReservation,
    ) -> None:
        started = time.monotonic()
        log_path = self.store.artifact_path(jobid, "log.txt")
        try:
            self.store.update(
                jobid,
                status="running",
                phase="external_execution",
                progress=0.05,
                started_at=utc_now(),
            )
            process_result = self._runner.run(
                reservation,
                command,
                cwd=self.store.job_dir(jobid),
                env=self._allowed_environment(),
                log_path=log_path,
                timeout_seconds=timeout,
                cancel=cancel,
                jobid=jobid,
                cancellation_message="ngspice job was cancelled",
                timeout_message=f"ngspice exceeded {timeout} seconds",
                on_started=lambda process: self._track_process(jobid, process),
                on_progress=lambda elapsed: self._update_external_progress(jobid, elapsed),
            )
            elapsed = process_result.elapsed_seconds
            summary = parse_ngspice_log(process_result.log_bytes)
            return_code = process_result.return_code
            if return_code != 0 or summary["error_lines"]:
                raise ExternalToolFailedError(
                    "ngspice reported a simulation failure",
                    details={
                        "return_code": return_code,
                        "error_lines": summary["error_lines"],
                    },
                    jobid=jobid,
                )
            self.store.update(
                jobid,
                status="completed",
                phase="completed",
                progress=1.0,
                elapsed_seconds=elapsed,
                completed_at=utc_now(),
                artifacts={
                    **self.store.read(jobid).artifacts,
                    "log": f"diptrace://job/{jobid}/log",
                },
                result={
                    "return_code": return_code,
                    **summary,
                    "resources": job_resources(jobid),
                },
            )
        except (JobCancelledError, JobTimeoutError, ExternalToolFailedError) as exc:
            status = "cancelled" if isinstance(exc, JobCancelledError) else "failed"
            self.store.update(
                jobid,
                status=status,
                phase=status,
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=exc.payload.as_dict(),
            )
        except Exception as exc:
            self.store.update(
                jobid,
                status="failed",
                phase="failed",
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=ExternalToolFailedError(
                    f"Could not execute ngspice: {exc}", jobid=jobid
                ).payload.as_dict(),
            )
        finally:
            reservation.release()
            with self._lock:
                self._processes.pop(jobid, None)
                self._cancel.pop(jobid, None)

    def _run_openems(
        self,
        jobid: str,
        command: list[str],
        output_path: Path,
        request: FieldSolverRequest,
        timeout: int,
        cancel: threading.Event,
        reservation: ExternalProcessReservation,
    ) -> None:
        started = time.monotonic()
        log_path = self.store.artifact_path(jobid, "log.txt")
        try:
            self.store.update(
                jobid,
                status="running",
                phase="external_execution",
                progress=0.05,
                started_at=utc_now(),
            )
            process_result = self._runner.run(
                reservation,
                command,
                cwd=self.store.job_dir(jobid),
                env=self._allowed_environment(),
                log_path=log_path,
                timeout_seconds=timeout,
                cancel=cancel,
                jobid=jobid,
                cancellation_message="openEMS job was cancelled",
                timeout_message=f"openEMS exceeded {timeout} seconds",
                on_started=lambda process: self._track_process(jobid, process),
                on_progress=lambda elapsed: self._update_external_progress(jobid, elapsed),
            )
            elapsed = process_result.elapsed_seconds
            return_code = process_result.return_code
            if return_code != 0:
                raise ExternalToolFailedError(
                    f"openEMS runner exited with status {return_code}",
                    details={"return_code": return_code},
                    jobid=jobid,
                )
            if not output_path.is_file() or output_path.stat().st_size == 0:
                raise ExternalToolFailedError(
                    "openEMS runner did not produce a non-empty result", jobid=jobid
                )
            if output_path.stat().st_size > self.settings.max_external_result_bytes:
                raise ExternalToolFailedError(
                    "openEMS result exceeds the configured size limit", jobid=jobid
                )
            result_bytes = output_path.read_bytes()
            try:
                result = parse_field_solver_result(result_bytes, request)
            except ExternalToolFailedError as exc:
                raise ExternalToolFailedError(str(exc), details=exc.details, jobid=jobid) from exc
            self.store.update(
                jobid,
                status="completed",
                phase="completed",
                progress=1.0,
                elapsed_seconds=elapsed,
                completed_at=utc_now(),
                artifacts={
                    **self.store.read(jobid).artifacts,
                    "result": f"diptrace://job/{jobid}/field_solver_result.json",
                    "log": f"diptrace://job/{jobid}/log",
                },
                result={
                    **result.model_dump(mode="json"),
                    "result_sha256": sha256_bytes(result_bytes),
                    "resources": job_resources(jobid),
                },
                warnings=result.warnings,
            )
        except (JobCancelledError, JobTimeoutError, ExternalToolFailedError) as exc:
            status = "cancelled" if isinstance(exc, JobCancelledError) else "failed"
            self.store.update(
                jobid,
                status=status,
                phase=status,
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=exc.payload.as_dict(),
            )
        except Exception as exc:
            self.store.update(
                jobid,
                status="failed",
                phase="failed",
                elapsed_seconds=time.monotonic() - started,
                completed_at=utc_now(),
                error=ExternalToolFailedError(
                    f"Could not execute openEMS runner: {exc}", jobid=jobid
                ).payload.as_dict(),
            )
        finally:
            reservation.release()
            with self._lock:
                self._processes.pop(jobid, None)
                self._cancel.pop(jobid, None)
