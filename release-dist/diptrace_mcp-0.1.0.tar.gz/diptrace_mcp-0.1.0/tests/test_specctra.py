from __future__ import annotations

import sys
import time
from pathlib import Path

import pytest

from diptrace_mcp.adapters import build_snapshot
from diptrace_mcp.config import Settings
from diptrace_mcp.errors import (
    CapabilityUnavailableError,
    DocumentError,
    Sha256MismatchError,
)
from diptrace_mcp.external_adapters import FreeroutingAdapter
from diptrace_mcp.service import DipTraceService
from diptrace_mcp.specctra import (
    _quote,
    dsn_export_limitations,
    export_dsn,
    parse_ses,
    session_to_operations,
)
from diptrace_mcp.xml_document import DipTraceDocument

FIXTURES = Path(__file__).parent / "fixtures"


class _PythonMockFreeroutingAdapter(FreeroutingAdapter):
    """Execute the fixture script explicitly so the subprocess test is portable."""

    def command(
        self,
        input_path: Path,
        output_path: Path,
        *,
        max_passes: int,
        threads: int,
        ignore_net_classes: list[str],
    ) -> list[str]:
        command = super().command(
            input_path,
            output_path,
            max_passes=max_passes,
            threads=threads,
            ignore_net_classes=ignore_net_classes,
        )
        return [sys.executable, *command]


def _embedded_board_bytes() -> bytes:
    raw = (FIXTURES / "pcb.xml").read_bytes()
    marker = b'<Library Type="DipTrace-PatternLibrary" Version="4.3.0.3" Units="mm" />'
    library = b"""<Library Type="DipTrace-PatternLibrary" Version="4.3.0.3" Units="mm">
    <PadStyles><PadStyle Name="SMD" Type="Surface" Side="Top">
      <MainStack Shape="Rectangle" Width="1" Height="0.8" />
    </PadStyle></PadStyles>
    <Patterns>
      <Pattern PatternStyle="PatType0"><Name>RES_0603</Name><DefPad Style="SMD" />
        <Pads><Pad Id="0" Style="SMD" X="0" Y="-1"><Number>1</Number></Pad>
          <Pad Id="1" Style="SMD" X="0" Y="0"><Number>2</Number></Pad></Pads>
      </Pattern>
      <Pattern PatternStyle="PatType1"><Name>TEST_MCU</Name><DefPad Style="SMD" />
        <Pads><Pad Id="0" Style="SMD" X="0" Y="-1"><Number>1</Number></Pad>
          <Pad Id="1" Style="SMD" X="0" Y="0"><Number>2</Number></Pad></Pads>
      </Pattern>
    </Patterns><UnknownCacheData Keep="Y" />
  </Library>"""
    return raw.replace(marker, library)


def _simple_ses(*, delay_coordinates: bool = False) -> bytes:
    x2 = "21000" if delay_coordinates else "20000"
    return f"""(session "result.ses"
  (base_design "board.dsn")
  (routes
    (resolution mm 1000)
    (parser (host_cad "mock"))
    (library_out)
    (network_out
      (net "VCC"
        (wire (path "Top" 250 10000 9000 {x2} 9000)))
    )
  )
)""".encode()


def _service(
    workspace: Path,
    state_dir: Path,
    executable: Path | None = None,
) -> DipTraceService:
    service = DipTraceService(
        Settings(
            workspace=workspace,
            allowed_roots=(workspace,),
            state_dir=state_dir,
            max_document_bytes=10_000_000,
            max_scan_files=100,
            freerouting_executable=executable,
            java_executable=None,
            external_timeout_seconds=10,
            max_external_log_bytes=4096,
        )
    )
    if executable is not None:
        service.external_jobs.freerouting = _PythonMockFreeroutingAdapter(service.settings)
    return service


def _wait_for_job(service: DipTraceService, jobid: str, timeout: float = 5.0) -> str:
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        status = service.jobs.read(jobid).status
        if status in {"completed", "failed", "cancelled"}:
            return status
        time.sleep(0.02)
    raise AssertionError(f"job did not finish: {jobid}")


def _mock_router(path: Path, ses: bytes, *, delay_seconds: float = 0.0) -> None:
    source = """#!/usr/bin/env python3
import pathlib
import sys
import time

args = sys.argv[1:]
output = pathlib.Path(args[args.index("-do") + 1])
time.sleep(DELAY)
output.write_bytes(SES)
print("mock freerouting complete")
""".replace("DELAY", repr(delay_seconds)).replace("SES", repr(ses))
    path.write_text(source, encoding="utf-8")
    path.chmod(0o755)


def test_dsn_export_requires_and_uses_exact_embedded_pattern_geometry(tmp_path: Path) -> None:
    incomplete = build_snapshot(DipTraceDocument.load(FIXTURES / "pcb.xml", 10_000_000))
    assert any("embedded pattern" in item for item in dsn_export_limitations(incomplete))
    board_path = tmp_path / "board.xml"
    document = DipTraceDocument.from_bytes(board_path, _embedded_board_bytes())
    snapshot = build_snapshot(document)

    first = export_dsn(snapshot, design_name="Golden Board")
    second = export_dsn(snapshot, design_name="Golden Board")

    assert first == second
    text = first.decode()
    assert text.startswith('(pcb "Golden Board"')
    assert "(resolution mm 1000)" in text
    assert '(image "PatType0"' in text
    assert '(pin "PAD_SMD" "1" 0 -1000)' in text
    assert '(pins "R1"-"1" "U1"-"1")' in text
    assert '(padstack "MCP_VIA_0"' in text
    assert "UnknownCacheData" not in text
    assert b"UnknownCacheData" in document.raw_bytes


@pytest.mark.parametrize(
    ("old", "new", "attribute"),
    [
        (b'TraceWidth="0.25"', b'TraceWidth="NaN"', "TraceWidth"),
        (b'TraceClearance="0.2"', b'TraceClearance="1e309"', "TraceClearance"),
    ],
)
def test_public_dsn_export_rejects_nonfinite_routing_defaults_with_xml_location(
    tmp_path: Path,
    old: bytes,
    new: bytes,
    attribute: str,
) -> None:
    raw = _embedded_board_bytes()
    assert raw.count(old) == 1
    board_path = tmp_path / "nonfinite-routing.xml"
    board_path.write_bytes(raw.replace(old, new, 1))
    service = _service(tmp_path, tmp_path / "state")

    with pytest.raises(DocumentError) as caught:
        service.export_autorouter_dsn(str(board_path))

    assert caught.value.details["element"] == "Routing"
    assert caught.value.details["attribute"] == attribute
    assert isinstance(caught.value.details["byte_offset"], int)


@pytest.mark.parametrize(
    ("value", "expected"),
    [
        ("", '""'),
        ("Board rev A", '"Board rev A"'),
        ("A (B) #1", '"A (B) #1"'),
        ("name-with_'[]{}", '"name-with_\'[]{}"'),
    ],
)
def test_dsn_quote_serializes_safe_printable_ascii_literally(
    value: str,
    expected: str,
) -> None:
    assert _quote(value) == expected


@pytest.mark.parametrize(
    ("value", "reason"),
    [
        ('A"B', "quote or backslash"),
        (r"A\B", "quote or backslash"),
        ("A\nB", "ASCII control character"),
        ("A\x7fB", "ASCII control character"),
        ("µBoard", "non-ASCII text"),
    ],
)
def test_dsn_quote_refuses_unverified_escape_and_encoding_conventions(
    value: str,
    reason: str,
) -> None:
    with pytest.raises(CapabilityUnavailableError) as exc_info:
        _quote(value)

    payload = exc_info.value.payload
    assert payload.code == "capability_unavailable"
    assert reason in payload.details["reasons"][0]


@pytest.mark.parametrize(
    ("design_name", "reason"),
    [
        ('Bad"board', "quote or backslash"),
        (r"Bad\board", "quote or backslash"),
        ("Bad\nboard", "ASCII control character"),
        ("µBoard", "non-ASCII text"),
    ],
)
def test_dsn_export_preflights_unsafe_design_name(
    tmp_path: Path,
    design_name: str,
    reason: str,
) -> None:
    document = DipTraceDocument.from_bytes(
        tmp_path / "board.xml",
        _embedded_board_bytes(),
    )
    snapshot = build_snapshot(document)

    limitations = dsn_export_limitations(snapshot, design_name=design_name)
    assert any(
        item.startswith("DSN design name contains") and reason in item
        for item in limitations
    )
    with pytest.raises(CapabilityUnavailableError) as exc_info:
        export_dsn(snapshot, design_name=design_name)
    assert exc_info.value.payload.details["reasons"] == limitations


@pytest.mark.parametrize(
    ("old", "new", "reason"),
    [
        (
            b"<Name>Top</Name>",
            "<Name>Tµp</Name>".encode(),
            "Copper layer 0 name contains non-ASCII text",
        ),
        (
            b"<RefDes>R1</RefDes>",
            b"<RefDes>R&quot;1</RefDes>",
            "reference designator contains a quote or backslash",
        ),
        (
            b"<Number>1</Number>",
            b"<Number>1\\2</Number>",
            "pad 0 number contains a quote or backslash",
        ),
    ],
)
def test_dsn_export_preflights_quoted_identifiers_from_document(
    tmp_path: Path,
    old: bytes,
    new: bytes,
    reason: str,
) -> None:
    raw = _embedded_board_bytes()
    assert old in raw
    document = DipTraceDocument.from_bytes(
        tmp_path / "board.xml",
        raw.replace(old, new, 1),
    )
    snapshot = build_snapshot(document)

    limitations = dsn_export_limitations(snapshot)
    assert any(reason in item for item in limitations)
    with pytest.raises(CapabilityUnavailableError) as exc_info:
        export_dsn(snapshot)
    assert exc_info.value.payload.details["reasons"] == limitations


@pytest.mark.parametrize(
    ("quoted_name", "message"),
    [
        (b'"A\\\\nB"', "Backslash escaping"),
        (b'"A\nB"', "Control characters"),
        (b'"A\tB"', "Control characters"),
    ],
)
def test_ses_parser_refuses_unverified_quoted_token_conventions(
    quoted_name: bytes,
    message: str,
) -> None:
    payload = _simple_ses().replace(b'"VCC"', quoted_name, 1)

    with pytest.raises(DocumentError, match=message) as caught:
        parse_ses(payload)

    assert caught.value.details["context"] == "quoted token"
    assert isinstance(caught.value.details["character_offset"], int)


def test_ses_parser_and_simple_route_conversion() -> None:
    document = DipTraceDocument.load(FIXTURES / "pcb.xml", 10_000_000)
    snapshot = build_snapshot(document)

    session = parse_ses(_simple_ses())
    plan = session_to_operations(snapshot, session)

    assert session.resolution_unit == "mm"
    assert session.routes[0].wires[0].width_mm == 0.25
    assert plan.imported_nets == ["VCC"]
    assert plan.metrics["importable_net_count"] == 1
    assert plan.operations[0].points[-1].x == 20.0


def test_ses_parser_rejects_malformed_and_nonmatching_route() -> None:
    with pytest.raises(DocumentError, match="Unclosed"):
        parse_ses(b'(session "bad" (routes')
    document = DipTraceDocument.load(FIXTURES / "pcb.xml", 10_000_000)
    plan = session_to_operations(
        build_snapshot(document), parse_ses(_simple_ses(delay_coordinates=True))
    )
    assert plan.operations == []
    assert plan.skipped == [{"net": "VCC", "reason": "route_endpoints_do_not_match_pads"}]


def test_mocked_freerouting_job_inspect_commit_and_rollback(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    board = workspace / "board.xml"
    board.write_bytes((FIXTURES / "pcb.xml").read_bytes())
    dsn = workspace / "board.dsn"
    dsn.write_text("(pcb mock)", encoding="utf-8")
    router = workspace / "mock-freerouting"
    _mock_router(router, _simple_ses())
    service = _service(workspace, tmp_path / "state", router)

    started = service.run_external_autorouter(str(board), dsn_path=str(dsn), max_passes=2)
    jobid = started["job"]["jobid"]
    assert _wait_for_job(service, jobid) == "completed"
    assert "mock freerouting complete" in service.job_resource(jobid, "log")

    inspected = service.inspect_autorouter_result(jobid)
    plan = inspected["result"]["plan"]
    assert plan["metrics"]["importable_net_count"] == 1
    preview = service.import_autorouter_ses(plan["plan_id"])
    txid = preview["transaction"]["txid"]
    committed = service.import_autorouter_ses(
        plan["plan_id"],
        dry_run=False,
        expected_sha256=preview["transaction"]["source_sha256"],
        txid=txid,
    )
    assert committed["transaction"]["status"] == "committed"
    reloaded = DipTraceDocument.load(board, 10_000_000)
    assert len(reloaded.container.findall("./Nets/Net[@Id='0']/Traces/Trace")) == 1
    rolled_back = service.rollback_transaction(
        txid, expected_sha256=committed["transaction"]["committed_sha256"]
    )
    assert rolled_back["transaction"]["status"] == "rolled_back"
    restored = DipTraceDocument.load(board, 10_000_000)
    assert len(restored.container.findall("./Nets/Net[@Id='0']/Traces/Trace")) == 0


def test_autorouter_inspection_rejects_source_sha_change(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    board = workspace / "board.xml"
    board.write_bytes((FIXTURES / "pcb.xml").read_bytes())
    dsn = workspace / "board.dsn"
    dsn.write_text("(pcb mock)", encoding="utf-8")
    router = workspace / "mock-freerouting"
    _mock_router(router, _simple_ses())
    service = _service(workspace, tmp_path / "state", router)
    jobid = service.run_external_autorouter(str(board), dsn_path=str(dsn))["job"]["jobid"]
    assert _wait_for_job(service, jobid) == "completed"
    board.write_bytes(board.read_bytes().replace(b"10k", b"11k", 1))

    with pytest.raises(Sha256MismatchError):
        service.inspect_autorouter_result(jobid)


def test_external_job_cancellation(tmp_path: Path) -> None:
    workspace = tmp_path / "workspace"
    workspace.mkdir()
    board = workspace / "board.xml"
    board.write_bytes((FIXTURES / "pcb.xml").read_bytes())
    dsn = workspace / "board.dsn"
    dsn.write_text("(pcb mock)", encoding="utf-8")
    router = workspace / "slow-freerouting"
    _mock_router(router, _simple_ses(), delay_seconds=2.0)
    service = _service(workspace, tmp_path / "state", router)
    jobid = service.run_external_autorouter(str(board), dsn_path=str(dsn))["job"]["jobid"]

    deadline = time.monotonic() + 2.0
    while jobid not in service.external_jobs._processes and time.monotonic() < deadline:
        time.sleep(0.01)
    assert jobid in service.external_jobs._processes

    service.cancel_job(jobid)

    assert _wait_for_job(service, jobid) == "cancelled"
    assert service.jobs.read(jobid).error["code"] == "job_cancelled"
