# Transactions

State machine: `planned -> staged -> validated -> committed`. A transaction may move to
`rolled_back` from an allowed state; an error moves it to `failed`.

## Pipeline

1. `begin_transaction` records the document ID, source SHA, and immutable snapshot.
2. `stage_operations` accepts only typed semantic operations.
3. `preview_transaction` compiles changes against a clone into byte-span patches over the
   original XML, reparses the result, stores XML diff, SVG, and JSON previews, and
   returns their resource URIs without echoing operations or artifacts.
4. Validation compares connectivity and DRC errors before and after the change.
5. `commit_transaction` requires an exact expected SHA, creates a backup, and performs an atomic write.
6. The document is reparsed after the write; the backup is restored if an exception occurs.
7. `rollback_transaction` checks for conflicts and restores the snapshot or backup.

A single high-level operation may contain many XML patches while remaining one
transaction. Unknown XML and original formatting outside modified nodes are preserved
byte-for-byte. Existing attribute and text changes patch only their raw spans; new
subtrees are serialized from typed operations. After compilation, the reparsed tree is
compared with the mutated domain/XML model. A mismatch fails instead of being written.
The low-level `apply_xml_edits` tool uses the same raw-preserving approach and remains a
separate expert API limited to 50 edits. Its diff is stored under a
`diptrace://raw-preview/{preview_id}/diff` resource. The response reports line and
character caps, total and stored sizes, and whether either cap truncated the artifact.
Per-edit results contain bounded XPath and match-count metadata without before/after
XML snippets, and the complete serialized response is capped at 128 KiB.

PCB SVG/JSON previews include normalized trace centerlines and exported copper-pour
boundaries even though those records have no single `position`. Changed trace geometry
is shown before and after; removed geometry remains visible in the before layer. This is
a review aid, not manufacturing artwork: arc triples are drawn as point-to-point chords,
and a pour is only its exported boundary, never claimed as authoritative refill,
thermals, cutouts, or islands.

Copper rendering is bounded to 500 records and 10,000 normalized points per preview
layer. `preview.json` reports the total, rendered, invalid, and omitted record counts,
the two limits, and `complete`/`truncated`. The SVG carries the same completeness state
in its `diptrace-copper-preview` metadata. A truncated or incomplete copper layer must
not be interpreted as a complete visual review.

## Semantic Operations v1

- component and part move, rotate, side, lock, value, fields, pattern, and group operations;
- text move, rotate, visibility, and style operations;
- schematic no-connect and net rename;
- NetClass, differential-pair, and length rules, plus net assignment;
- test-point add, move, and remove;
- trace/via add, replace, move, delete, and style operations.

## Resources

`summary`, `operations`, `diff`, `preview.svg`, and `preview.json` are available at
`diptrace://transaction/{txid}/...`. Transaction tool responses expose a bounded
summary with `operation_count`; the operation payload is available only through the
`operations` resource. Diff metadata includes separate total/stored line and character
counts. The truncation marker is included in both stored caps. Runtime capabilities
publish `max_preview_copper_records` and `max_preview_copper_points`. PNG output is not
advertised.
